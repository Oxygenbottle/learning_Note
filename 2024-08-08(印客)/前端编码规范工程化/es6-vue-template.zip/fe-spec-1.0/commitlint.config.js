module.exports = {
  extends: ['./packages/commitlint-config/index.js'],
};
